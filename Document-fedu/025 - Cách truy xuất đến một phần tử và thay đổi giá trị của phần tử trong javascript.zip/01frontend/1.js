﻿var x1  = document.getElementsByTagName('h1');
//console.log(x1);

var x2 = document.getElementsByTagName("h2");			
console.log(x2[0]);		

var p1 = document.getElementsByTagName('p')	;
console.log(p1[1].innerHTML);			
p1[1].innerHTML =" Web da bi hack";