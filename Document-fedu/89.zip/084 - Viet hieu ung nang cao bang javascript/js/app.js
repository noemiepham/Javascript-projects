
var nutPhai = document.querySelector('.nuts b.phai'),
 	nutTrai = document.querySelector('.nuts b.trai');	

// 1. xac dinh slide hien tai va slide tiep theo khi click nut next

// goi su kien click vao nut phai
var chuyenSlideChoNutPhai = function(){
	console.log('click duoc chua');			
};
nutPhai.addEventListener('click',chuyenSlideChoNutPhai);
