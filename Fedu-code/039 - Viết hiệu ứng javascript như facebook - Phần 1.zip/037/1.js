﻿document.addEventListener("DOMContentLoaded",function(){
	// khai bao bien can su dung trong app nay 
	var tamgiac = document.getElementsByClassName('tamgiac');
	var tamgiac = tamgiac[0];
	var danhsach = document.getElementsByClassName('danhsach');
	var danhsach = danhsach[0];

	// su dung ham onclick va toggle Class cho tam giac doi mau
	tamgiac.onclick = function(){
		this.classList.toggle('tamgiactrang');
	}


},false)
